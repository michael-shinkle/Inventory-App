package com.zybooks.michaelshinkleinventoryapp;

import static java.lang.Integer.parseInt;
import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddInventoryItem extends AppCompatActivity {
    private TextView incButton, decButton;
    private EditText itemName, itemQuantity;
    private Button createItemButton, cancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_inventory_item);

        // get interface items from UI
        incButton = findViewById(R.id.incitemcount);
        decButton = findViewById(R.id.decitemcount);
        itemName = findViewById(R.id.additemname);
        itemQuantity = findViewById(R.id.additemquantity);
        createItemButton = findViewById(R.id.additembutton);
        cancelButton = findViewById(R.id.cancelbutton);


        incButton.setOnClickListener(v -> {
            // increment quantity and display it on screen
            int quantity = parseInt(itemQuantity.getText().toString());
            quantity++;
            itemQuantity.setText(Integer.toString(quantity));
        });

        decButton.setOnClickListener(v -> {
            // decrement quantity and display it on screen
            int quantity = parseInt(itemQuantity.getText().toString());
            if(quantity > 0){
                quantity--;
            }
            itemQuantity.setText(Integer.toString(quantity));
        });

        createItemButton.setOnClickListener(v -> {
            //Index is derived from DB so temp is used for constructor
            int tempIndex = 0;
            // get values from screen
            String name = itemName.getText().toString();
            int quantity = parseInt(itemQuantity.getText().toString());

            InventoryDBHandler db = new InventoryDBHandler(AddInventoryItem.this);

            InventoryItem newItem = new InventoryItem(tempIndex, name, quantity);
            // add item to database
            boolean result = db.addNewItem(newItem);
            // update user and return to inventory activity
            if (result) {
                Toast.makeText(AddInventoryItem.this, "Item added to inventory.", Toast.LENGTH_SHORT).show();
                setResult(Activity.RESULT_OK);
                finish();
            } else {
                Toast.makeText(AddInventoryItem.this, "Could not update inventory", Toast.LENGTH_SHORT).show();
            }
        });

        // return to inventory activity
        cancelButton.setOnClickListener(v -> finish());
    }
}
