package com.zybooks.michaelshinkleinventoryapp;

import android.os.Parcel;
import android.os.Parcelable;

public class InventoryItem implements Parcelable {
    private int index;
    private String itemName;
    private int itemCount;


    public InventoryItem(int index, String itemName, int itemCount){
        this.index = index;
        this.itemName = itemName;
        this.itemCount = itemCount;

    }

    public int getIndex() {
        return index;
    }

    public String getItemName() {
        return this.itemName;
    }

    public int getItemCount() {
        return this.itemCount;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }

    @Override
    public int describeContents() {
        //Auto-generated stub
        return 0;
    }

    // parcelable methods allow objects to be passed to and from activities
    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(index);
        parcel.writeString(itemName);
        parcel.writeInt(itemCount);
    }

    public InventoryItem(Parcel in){
        index = in.readInt();
        itemName = in.readString();
        itemCount = in.readInt();
    }

    public static final Parcelable.Creator<InventoryItem> CREATOR = new Parcelable.Creator<InventoryItem>(){
        public InventoryItem createFromParcel(Parcel in){
            return new InventoryItem(in);
        }

        public InventoryItem[] newArray(int size){
            return new InventoryItem[size];
        }
    };
}
