package com.zybooks.michaelshinkleinventoryapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    private EditText username, password;
    private Button loginButton, createAccount;

    private UserDBHandler userDBHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        // get interface from UI
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        createAccount = findViewById(R.id.createAccount);


        // open user database
        userDBHandler = new UserDBHandler(Login.this);

        loginButton.setOnClickListener(v -> {
            // get text from UI
            String name = username.getText().toString();
            String pass = password.getText().toString();

            if (name.isEmpty()) {
                Toast.makeText(Login.this, "Please enter a username.", Toast.LENGTH_SHORT).show();
            } else if (pass.isEmpty()) {
                Toast.makeText(Login.this, "Please enter a password.", Toast.LENGTH_SHORT).show();
            } else {
                // check database for username and password
                boolean checkLogin = userDBHandler.checkUsernamePassword(name, pass);
                if(checkLogin){
                    // create user object from database and send it to inventory activity
                    User user = userDBHandler.getUser(name);
                    Toast.makeText(Login.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Login.this, Inventory.class);
                    intent.putExtra("user", user);
                    startActivity(intent);
                } else {
                    Toast.makeText(Login.this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        createAccount.setOnClickListener(v -> {
            // start register activity
            Intent intent = new Intent(Login.this, Register.class);
            startActivity(intent);
        });


    }


}
