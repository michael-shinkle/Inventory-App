package com.zybooks.michaelshinkleinventoryapp;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import android.telephony.SmsManager;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReference;


public class Inventory extends AppCompatActivity {
    // flag codes
    private static final int SMS_PERMISSION_CODE = 1;
    private static final int UPDATE_ITEM = 0;
    private static final int ADD_ITEM = 1;

    String[] permissions = {Manifest.permission.SEND_SMS};

    private TextView addItem;
    GridView inventoryGV;

    InventoryDBHandler inventoryDB = new InventoryDBHandler(Inventory.this);
    ArrayList<InventoryItem> inventoryItems;

    User user;
    InventoryItem item;
    boolean flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory);
        flag = false;
        // get user that passed in from login
        user = getIntent().getParcelableExtra("user");

        // if permissions haven't been asked
        ActivityCompat.requestPermissions(Inventory.this, permissions, SMS_PERMISSION_CODE);

        //get interface from ui
        addItem = findViewById(R.id.additem);
        inventoryGV = findViewById(R.id.inventory);

        // load inventory items from database
        inventoryItems = inventoryDB.loadInventory();

        // set adapter to display items in grid view
        AtomicReference<InventoryGVAdapter> adapter = new AtomicReference<>(new InventoryGVAdapter(this, inventoryItems));
        inventoryGV.setAdapter(adapter.get());

        inventoryGV.setOnItemClickListener((adapterView, view, position, id) -> {
            // checks which inventory item is clicked on
            item = inventoryItems.get(position);
            switch(view.getId())
            {
                case R.id.editbutton:
                    // if edit button, opens edit item activity
                    Intent intent = new Intent(Inventory.this, EditInventoryItem.class);
                    intent.putExtra("item", item);
                    intent.putExtra("user", user);
                    startActivityForResult(intent, UPDATE_ITEM);
                    break;
                case R.id.deletebutton:
                    // delete item from list
                    boolean success = inventoryDB.deleteItem(item);
                    if(success){
                        inventoryItems.clear();
                        inventoryItems = inventoryDB.loadInventory();
                        adapter.set(new InventoryGVAdapter(this, inventoryItems));
                        inventoryGV.setAdapter(adapter.get());
                        Toast.makeText(Inventory.this, item.getItemName() + " removed.", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(Inventory.this, "Could not delete item.", Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        });


        // goes to add item activity
        addItem.setOnClickListener(v -> {
            Intent intent = new Intent(Inventory.this, AddInventoryItem.class);
            startActivityForResult(intent, ADD_ITEM);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // if item was updated
        if (requestCode == UPDATE_ITEM && resultCode == Activity.RESULT_OK){
            // clear inventory and reload it from database
            inventoryItems.clear();
            inventoryItems = inventoryDB.loadInventory();
            // get item and user from passed data
            item = data.getParcelableExtra("item");
            user = data.getParcelableExtra("user");

            flag = true;

            if (item.getItemCount() == 0){
                // if permission granted
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED){
                    // send SMS informing user that quantity is 0
                    sendSMSMessage(user, item);
                }
                else{
                    // ask for permission
                    ActivityCompat.requestPermissions(Inventory.this, permissions, SMS_PERMISSION_CODE);
                    Toast.makeText(Inventory.this, "SMS Permission Needed.", Toast.LENGTH_SHORT).show();
                }
            }
            // set adapter to display updated grid view
            InventoryGVAdapter adapter = new InventoryGVAdapter(this, inventoryItems);
            inventoryGV.setAdapter(adapter);
        } else if (requestCode == ADD_ITEM &&  resultCode == Activity.RESULT_OK) {
            // clear inventory and reload it from database
            inventoryItems.clear();
            inventoryItems = inventoryDB.loadInventory();
            // set adapter to display updated grid view
            InventoryGVAdapter adapter = new InventoryGVAdapter(this, inventoryItems);
            inventoryGV.setAdapter(adapter);
        }

    }

    public void sendSMSMessage(User user, InventoryItem item){
        SmsManager sm = SmsManager.getDefault();
        String phoneNumber = user.getPhoneNumber();
        String message = item.getItemName() + "'s quantity has reduced to 0!";

        sm.sendTextMessage(phoneNumber, null, message, null, null);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case SMS_PERMISSION_CODE:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && flag){
                    sendSMSMessage(user, item);
                }
                break;

        }
    }
}