package com.zybooks.michaelshinkleinventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    private EditText usernameReg, passwordReg, verifyPasswordReg, phoneReg;
    private Button createAccountReg;
    private UserDBHandler userDBHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        // get interface from ui
        usernameReg = findViewById(R.id.usernameReg);
        passwordReg = findViewById(R.id.passwordReg);
        phoneReg = findViewById(R.id.phonenumberReg);
        verifyPasswordReg = findViewById(R.id.verifyPasswordReg);
        createAccountReg = findViewById(R.id.createAccountReg);

        // start user database
        userDBHandler = new UserDBHandler(Register.this);

        createAccountReg.setOnClickListener(v -> {
            // get variable data from UI
            String username = usernameReg.getText().toString();
            String password = passwordReg.getText().toString();
            String phone = phoneReg.getText().toString();
            String verifyPassword = verifyPasswordReg.getText().toString();

            if (username.isEmpty()) {
                Toast.makeText(Register.this, "Please enter a username.", Toast.LENGTH_SHORT).show();
            } else if (password.isEmpty()) {
                Toast.makeText(Register.this, "Please enter a password.", Toast.LENGTH_SHORT).show();
            } else if  (phone.length() != 10){
                Toast.makeText(Register.this, "Please enter a valid phone number (ie. 5555215554).", Toast.LENGTH_SHORT).show();
            } else if (!password.equals(verifyPassword)) {
                Toast.makeText(Register.this, "Passwords do not match.", Toast.LENGTH_SHORT).show();
            } else {
                boolean checkUserName = userDBHandler.checkUsernameExists(username);
                // if userrname does not exist create new user and add it to database
                if (checkUserName) {
                    Toast.makeText(Register.this, "Username already exists.", Toast.LENGTH_LONG).show();
                } else {
                    //id is derived from database so set to 0 temporarily
                    int id = 0;
                    User newUser = new User(id, username, password, phone);
                    boolean success = userDBHandler.addNewUser(newUser);
                    if (success) {
                        Toast.makeText(Register.this, "Successfully Created Account", Toast.LENGTH_LONG).show();
                        finish();
                    } else {
                        Toast.makeText(Register.this, "Account Not Created", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
}
