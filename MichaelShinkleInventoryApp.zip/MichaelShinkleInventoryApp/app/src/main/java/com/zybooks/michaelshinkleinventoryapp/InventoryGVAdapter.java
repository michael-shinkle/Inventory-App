package com.zybooks.michaelshinkleinventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;

public class InventoryGVAdapter extends ArrayAdapter<InventoryItem> {
    public InventoryGVAdapter(@NonNull Context context, ArrayList<InventoryItem> inventoryItems){
        super(context, 0, inventoryItems);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View inventoryView = convertView;
        // set view to inventory_item.xml
        if (inventoryView == null){
            inventoryView = LayoutInflater.from(getContext()).inflate(R.layout.inventory_item, parent, false);
        }

        // get interface from UI
        TextView itemName = inventoryView.findViewById(R.id.itemname);
        TextView itemCount = inventoryView.findViewById(R.id.itemcount);
        TextView editButton = inventoryView.findViewById(R.id.editbutton);
        TextView deleteButton = inventoryView.findViewById(R.id.deletebutton);

        //update UI with item object values
        InventoryItem item = getItem(position);
        itemName.setText(item.getItemName());
        itemCount.setText(String.valueOf(item.getItemCount()));
        editButton.setTag(position);
        deleteButton.setTag(position);

        // listeners to detect edit and delete buttons within grid view adapter
        editButton.setOnClickListener(view -> ((GridView)parent).performItemClick(view, position, 0));
        deleteButton.setOnClickListener(view -> ((GridView)parent).performItemClick(view, position, 0));

        return inventoryView;
    }
}
