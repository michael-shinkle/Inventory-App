package com.zybooks.michaelshinkleinventoryapp;

import static java.lang.Integer.parseInt;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditInventoryItem extends AppCompatActivity {
    private TextView incButton, decButton;
    private EditText itemName, itemQuantity;
    private Button editItemButton, cancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_inventory_item);

        // get item and user that is passed through intent into edit inventory activity
        InventoryItem item = (InventoryItem) getIntent().getParcelableExtra("item");
        User user = (User) getIntent().getParcelableExtra("user");

        // get interface from UI
        incButton = findViewById(R.id.incedititemcount);
        decButton = findViewById(R.id.decedititemcount);
        itemName = findViewById(R.id.edititemname);
        itemQuantity = findViewById(R.id.edititemquantity);
        editItemButton = findViewById(R.id.edititembutton);
        cancelButton = findViewById(R.id.editcancelbutton);

        // auto populate fields with data from item that was passed in
        itemName.setText(item.getItemName());
        itemQuantity.setText(Integer.toString(item.getItemCount()));

        incButton.setOnClickListener(v -> {
            // increment quantity and display it on screen
            int quantity = parseInt(itemQuantity.getText().toString());
            quantity++;
            itemQuantity.setText(Integer.toString(quantity));
        });

        decButton.setOnClickListener(v -> {
            // decrement quantity and display it on screen
            int quantity = parseInt(itemQuantity.getText().toString());
            if(quantity > 0){
                quantity--;
            }
            itemQuantity.setText(Integer.toString(quantity));
        });

        editItemButton.setOnClickListener(v -> {
            // update item with new values
            item.setItemName(itemName.getText().toString());
            item.setItemCount(parseInt(itemQuantity.getText().toString()));

            InventoryDBHandler db = new InventoryDBHandler(EditInventoryItem.this);
            // update database with new values
            boolean result = db.updateItem(item);
            // inform user and return to inventory activity
            if (result) {
                Toast.makeText(EditInventoryItem.this, "Inventory Updated", Toast.LENGTH_SHORT).show();
                // add user and item to result because SMS notifications require those two objects
                setResult(Activity.RESULT_OK, new Intent().putExtra("item", item).putExtra("user", user));
                finish();
            } else {
                Toast.makeText(EditInventoryItem.this, "Could not update inventory", Toast.LENGTH_SHORT).show();
            }
        });
        // return to inventory activity
        cancelButton.setOnClickListener(v -> finish());
    }

}
