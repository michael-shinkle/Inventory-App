package com.zybooks.michaelshinkleinventoryapp;


import android.os.Parcel;
import android.os.Parcelable;

public class User implements Parcelable {
    private int id;
    private String username;
    private String password;
    private String phoneNumber;

    // Constructor
    public User(int id, String username, String password, String phoneNumber){
        this.id = id;
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
    }

    // returns formatted phone number
    public String formatPhoneNumber() {
        // emulator's phone number is +1-555-123-4567
        return "+1-" + this.phoneNumber.substring(0,3) + "-" + this.phoneNumber.substring(3, 6) + "-" + this.phoneNumber.substring(6,10);
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getId() {
        return id;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public int describeContents() {
        //Auto-generated Stub
        return 0;
    }

    // parcelable methods allow user to be sent to activities
    @Override
    public void writeToParcel(Parcel parcel, int i){
        parcel.writeInt(id);
        parcel.writeString(username);
        parcel.writeString(password);
        parcel.writeString(phoneNumber);
    }

    public User(Parcel in){
        id = in.readInt();
        username = in.readString();
        password = in.readString();
        phoneNumber = in.readString();
    }

    public static final Parcelable.Creator<User> CREATOR = new Parcelable.Creator<User>(){
        public User createFromParcel(Parcel in) { return new User(in); }

        public User[] newArray(int size) { return new User[size]; }
    };
}
