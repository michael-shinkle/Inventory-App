package com.zybooks.michaelshinkleinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDBHandler extends SQLiteOpenHelper {

    // database variables
    private static final String DB_NAME = "userDB";
    private static final int DB_VERSION = 4;
    private static final String TABLE_NAME = "users";
    private static final String ID_COL = "id";
    private static final String NAME_COL = "name";
    private static final String PASS_COL = "password";
    private static final String PHONE_COL = "phonenumber";

    public UserDBHandler(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // create database table
        String query = "CREATE TABLE " + TABLE_NAME + "("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT,"
                + PASS_COL + " TEXT,"
                + PHONE_COL + " TEXT)";

        db.execSQL(query);
    }

    public boolean addNewUser(User user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // add user values to content
        values.put(NAME_COL, user.getUsername());
        values.put(PASS_COL, user.getPassword());
        values.put(PHONE_COL, user.getPhoneNumber());

        long result = db.insert(TABLE_NAME, null, values);
        db.close();
        if (result == -1){
            // failed
            return false;
        }
        else{
            // success
            return true;
        }
    }

    public boolean checkUsernameExists(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        // move cursor to row that matches username query
        Cursor cursor = db.rawQuery("Select * from " + TABLE_NAME + " where " + NAME_COL + " = ?", new String[]{username});
        //if cursor has more than 0 entries, then userrname exists
        if(cursor.getCount() > 0){
            cursor.close();
            return true;
        }
        else{
            cursor.close();
            return false;
        }
    }

    public boolean checkUsernamePassword(String username, String password){
        SQLiteDatabase db = this.getReadableDatabase();
        // move cursor to row that matches username and password query
        Cursor cursor = db.rawQuery("Select * from " + TABLE_NAME + " where " + NAME_COL + " = ? and " + PASS_COL + " = ?",
                new String[]{username, password});
        //if cursor has more than 0 entries, then userrname and password matches
        if(cursor.getCount() > 0){
            cursor.close();
            return true;
        }
        else{
            cursor.close();
            return false;
        }
    }

    public User getUser(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        // move cursor to row that matches username query
        Cursor cursor = db.rawQuery("Select * from " + TABLE_NAME + " where " + NAME_COL + " = ?", new String[]{username});

        // if username is in database, move cursor to first instance of it
        if (cursor.getCount() > 0){
            cursor.moveToFirst();
        }
        // get values from database, and return User with those values
        int id = cursor.getInt(0);
        String pass = cursor.getString(2);
        String phone = cursor.getString(3);
        cursor.close();
        return new User(id, username, pass, phone);

    }

    public boolean updateUser(User user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        // add updated values to content
        values.put(NAME_COL, user.getUsername());
        values.put(PASS_COL, user.getPassword());

        // update database row that matches index of item
        long result = db.update(TABLE_NAME, values, ID_COL + " = ?", new String[]{String.valueOf(user.getId())});
        if(result == -1){
            // failed
            return false;
        } else {
            // success
            return true;
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
