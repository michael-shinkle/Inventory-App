package com.zybooks.michaelshinkleinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;


public class InventoryDBHandler extends SQLiteOpenHelper {

    // Database constants
    private static final String DB_NAME = "inventoryDB";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "inventory";
    private static final String ID_COL = "id";
    private static final String NAME_COL = "name";
    private static final String QUANT_COL = "quantity";

    // constructor
    public InventoryDBHandler(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + "("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT,"
                + QUANT_COL + " INTEGER)";

        db.execSQL(query);
    }

    public boolean addNewItem(InventoryItem item){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        // add values to content
        values.put(NAME_COL, item.getItemName());
        values.put(QUANT_COL, item.getItemCount());
        // insert
        long result = db.insert(TABLE_NAME, null, values);
        if (result == -1){
            // failed
            return false;
        }
        else{
            // success
            return true;
        }
    }

    public boolean updateItem(InventoryItem item){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        // add updated values to content
        values.put(NAME_COL, item.getItemName());
        values.put(QUANT_COL, item.getItemCount());

        // update database row that matches index of item
        long result = db.update(TABLE_NAME, values, ID_COL + " = ?", new String[]{String.valueOf(item.getIndex())});
        if(result == -1){
            // failed
            return false;
        } else {
            // success
            return true;
        }
    }

    public boolean deleteItem(InventoryItem item){
        SQLiteDatabase db = this.getWritableDatabase();
        // remove db row that matches the index of the item
        long result = db.delete(TABLE_NAME, ID_COL + " = ?", new String[]{String.valueOf(item.getIndex())});
        if(result == -1){
            // failed
            return false;
        }
        else{
            // success
            return true;
        }
    }

    public ArrayList<InventoryItem> loadInventory() {
        ArrayList<InventoryItem> inventoryList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        // move cursor to beginning of db
        Cursor cursor = db.rawQuery("Select * From " + TABLE_NAME, null);

        // move cursor through db, creating inventory items and adding to array list for each iteration
        if(cursor.moveToFirst()){
            do {
                int index = cursor.getInt(0);
                String name = cursor.getString(1);
                int quant = cursor.getInt(2);
                InventoryItem newItem = new InventoryItem(index, name, quant);

                inventoryList.add(newItem);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return inventoryList;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
